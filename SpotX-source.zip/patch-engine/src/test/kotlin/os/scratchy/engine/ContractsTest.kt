package os.scratchy.engine

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ContractsTest {
    @Test fun `unknown target has an explicit rejection diagnostic`() {
        val result: InspectionResult = InspectionResult.Rejected(Diagnostic("unknown-target", "Unsupported package"))
        assertTrue(result is InspectionResult.Rejected)
        assertFalse((result as InspectionResult.Rejected).diagnostic.message.isBlank())
    }
}
