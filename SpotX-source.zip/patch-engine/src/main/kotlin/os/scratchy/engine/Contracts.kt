package os.scratchy.engine

/** Android-independent contracts for a fail-closed APK transformation pipeline. */
data class TargetIdentity(val packageName: String, val versionName: String, val versionCode: Long)

sealed interface InspectionResult {
    data class Identified(val target: TargetIdentity) : InspectionResult
    data class Rejected(val diagnostic: Diagnostic) : InspectionResult
}

data class Diagnostic(val code: String, val message: String)

interface TargetInspector<Input> {
    fun inspect(input: Input): InspectionResult
}

interface PatchDefinition<Input> {
    val id: String
    val description: String
    fun supports(target: TargetIdentity): Boolean
    fun validatePreconditions(input: Input): Diagnostic?
    fun apply(input: Input): Result<Input>
    fun validateResult(output: Input): Diagnostic?
}
