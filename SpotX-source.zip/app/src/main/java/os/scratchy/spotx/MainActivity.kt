package os.scratchy.spotx

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Ink = Color(0xFF101114)
private val Lime = Color(0xFFCBFF46)
private val Panel = Color(0xFF202329)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) = super.onCreate(savedInstanceState).also {
        setContent { ScratchyApp() }
    }
}

@Composable
private fun ScratchyApp() {
    var chosenFile by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        chosenFile = uri?.lastPathSegment ?: "Selected APK"
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Lime, surface = Panel, background = Ink)) {
        Scaffold(containerColor = Ink) { inset ->
            Column(Modifier.fillMaxSize().padding(inset).padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Text("scratchy", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = Color.White)
                Text("SpotX for Android", color = Lime, style = MaterialTheme.typography.titleMedium)
                Text("Inspect an APK before any transformation. Unknown versions fail closed and no source file is changed in place.", color = Color.LightGray)
                Surface(color = Panel, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.Security, null, tint = Lime)
                        Text("APK workspace", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(chosenFile ?: "Choose an APK to begin package and version inspection.", color = Color.LightGray)
                        Button(onClick = { picker.launch(arrayOf("application/vnd.android.package-archive")) }) {
                            Icon(Icons.Default.FolderOpen, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Select APK")
                        }
                    }
                }
                Text("Pipeline", color = Lime, fontWeight = FontWeight.SemiBold)
                listOf("Inspect package and version", "Evaluate compatible benign patches", "Apply to a working copy", "Validate result and report diagnostics").forEachIndexed { index, step ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("0${index + 1}", color = Lime, modifier = Modifier.width(42.dp), fontWeight = FontWeight.Bold)
                        Text(step, color = Color.White)
                    }
                }
            }
        }
    }
}
