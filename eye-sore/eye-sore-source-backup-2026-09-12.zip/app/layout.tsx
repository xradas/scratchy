import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Eye Sore — Furnace Descent',
  description: 'An original occult-industrial first-person action prototype.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
